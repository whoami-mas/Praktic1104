﻿
using Praktic1104;

Dictionary<int,string> LineDictionary = new Dictionary<int, string>() 
{
    {1,"The"},
    {2,"unfolding"},
    {3,"years"}
};

var text = "The events unfolding on a tapestry took place in the years 1064 to 1066. " +
    "Anglo-Saxon earl Harold Godwinson is depicted receiving the English crown from " +
    "Edward the Confessor, a deathly ill English monarch.";
var textArray = text.Split(' ','.');
int countLine = 0;
int countLine1 = 0;
int countLine2 = 0;

foreach (var item in textArray)
{
    foreach (var value in LineDictionary)
    {
        if (item.ToLower() == value.Value.ToLower())
        {
            countLine++;
        }
    }
}

Console.Write(countLine);


DynamicArray DA = new DynamicArray(3) { 1, "sdf", 3 };