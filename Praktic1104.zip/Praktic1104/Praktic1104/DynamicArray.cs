﻿using System.Collections;

namespace Praktic1104
{
    public class DynamicArray : System.Collections.IEnumerable
    {
        object[] data;
        public int Length { get; set; }
        public int Capacity { get; set; }

        /// <summary>
        /// создаётся массив ёмкостью 8 элементов
        /// </summary>
        public DynamicArray()
        {
            Length = 8;
            data = new object[8];
        }

        /// <summary>
        /// создаётся массив указанной ёмкости
        /// </summary>
        /// <param name="length">длина массива</param>
        public DynamicArray(int length)
        {
            Length = length;
            data = new object[length];
        }

        /// <summary>
        /// в качестве параметра принимает коллекцию, 
        /// реализующую интерфейс IEnumerable<T>, создаёт массив нужного размера и копирует в него все элементы из коллекции.
        /// </summary>
        /// <param name=""></param>
        public DynamicArray(IEnumerable<object> array)
        {
            data = new object[] { array };
        }

        /// <summary>
        /// добавляющий в конец массива один элемент. 
        /// При нехватке места для добавления элемента, ёмкость массива удваивается.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public DynamicArray Add(object value)
        {
            Array.Resize(ref data, data.Length + 1);
            data[data.Length - 1] = value;
            return this;
        }

        /// <summary>
        /// 
        /// </summary>
        public void AddRange()
        {

        }

        public bool Remove(object item)
        {
            data.Where(f => f != item).ToArray();

            return true;
        }

        public void Insert()
        {

        }

        public IEnumerator GetEnumerator()
        {
            return data.GetEnumerator();
        }
    }
}
